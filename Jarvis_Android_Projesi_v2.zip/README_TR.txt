JARVIS - ilk Android prototipi

Bu klasör bir Android Studio/Gradle kaynak projesidir; henüz APK değildir.

İlk prototipte:
- Sade ana ekran
- Dokunarak Türkçe konuşma tanıma
- Türkçe metinden konuşma (cihazda yüklü ses motoruna bağlı)
- "Jarvis" veya "merhaba" denince "Efendim Mert Bey?"
- "Saat kaç?" ve "Nasılsın?" örnek komutları

Önemli sınırlamalar:
- EXTRA_PREFER_OFFLINE yalnızca çevrimdışı tanımayı tercih eder; cihazdaki dil paketi ve konuşma hizmeti desteklemiyorsa internet gerekebilir.
- Bu prototip ekran kapalıyken sürekli uyandırma kelimesi dinlemez.
- Arama/SMS henüz eklenmedi.
- Kadın ses seçimi Android'in kurulu Türkçe TTS seslerine bağlıdır; her cihazda garanti değildir.
- Gerçek cihazda izinler ve davranış test edilmelidir.

Derleme için Android SDK ve Gradle gerekir. Bu dosyaları güvenilir bir Android derleme ortamında açıp APK üretmek gerekir.
