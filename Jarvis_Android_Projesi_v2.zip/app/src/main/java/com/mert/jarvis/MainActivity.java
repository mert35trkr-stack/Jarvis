package com.mert.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status, heard;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("tr", "TR"));
                ttsReady = true;
            }
        });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new SimpleRecognitionListener(
                text -> runOnUiThread(() -> handleSpeech(text)),
                error -> runOnUiThread(() -> {
                    status.setText("Dinleme tamamlanamadı. Tekrar deneyebilirsin.");
                    Toast.makeText(this, "Ses tanıma hatası: " + error, Toast.LENGTH_SHORT).show();
                })
            ));
        } else {
            status.setText("Bu cihazda konuşma tanıma servisi bulunamadı.");
        }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 36, 28, 36);
        root.setBackgroundColor(0xFFF5F6F7);

        TextView title = new TextView(this);
        title.setText("JARVIS");
        title.setTextSize(30);
        title.setTextColor(0xFF263238);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("Hazırım Mert Bey.");
        status.setTextSize(17);
        status.setTextColor(0xFF455A64);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 28;
        root.addView(status, sp);

        Button listen = new Button(this);
        listen.setText("Konuşmak için dokun");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 30;
        root.addView(listen, bp);
        listen.setOnClickListener(v -> startListening());

        heard = new TextView(this);
        heard.setText("Söylediklerin burada görünecek.");
        heard.setTextSize(15);
        heard.setTextColor(0xFF607D8B);
        heard.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = 24;
        root.addView(heard, hp);

        Button greet = new Button(this);
        greet.setText("Jarvis'i dene");
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = 18;
        root.addView(greet, gp);
        greet.setOnClickListener(v -> speak("Efendim Mert Bey?"));

        setContentView(root);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
            return;
        }
        if (recognizer == null) {
            status.setText("Konuşma tanıma kullanılamıyor.");
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        status.setText("Dinliyorum...");
        recognizer.startListening(intent);
    }

    private void handleSpeech(String text) {
        heard.setText("“" + text + "”");
        status.setText("Komut alındı.");
        String s = text.toLowerCase(new Locale("tr", "TR"));
        if (s.contains("jarvis") || s.contains("merhaba")) {
            speak("Efendim Mert Bey?");
        } else if (s.contains("saat kaç")) {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm", new Locale("tr", "TR"));
            speak("Saat " + f.format(new java.util.Date()));
        } else if (s.contains("nasılsın")) {
            speak("İyiyim Mert Bey. Size nasıl yardımcı olabilirim?");
        } else {
            speak("Komutunuzu duydum Mert Bey. Bu özellik henüz eklenmedi.");
        }
    }

    private void speak(String text) {
        status.setText(text);
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    interface ResultCallback { void onResult(String text); }
    interface ErrorCallback { void onError(int error); }

    static class SimpleRecognitionListener implements android.speech.RecognitionListener {
        private final ResultCallback result;
        private final ErrorCallback error;
        SimpleRecognitionListener(ResultCallback r, ErrorCallback e) { result = r; error = e; }
        public void onResults(Bundle b) {
            ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty()) result.onResult(list.get(0));
        }
        public void onError(int e) { error.onError(e); }
        public void onReadyForSpeech(Bundle b) {}
        public void onBeginningOfSpeech() {}
        public void onRmsChanged(float r) {}
        public void onBufferReceived(byte[] b) {}
        public void onEndOfSpeech() {}
        public void onPartialResults(Bundle b) {}
        public void onEvent(int t, Bundle b) {}
    }
}
